import os,shutil
import numpy as np
import scipy as sp
from scipy.io import wavfile as wv
from scipy.fftpack import fft,fftfreq
import simpleaudio as sa
from pylab import *
import matplotlib.pyplot as plt
import biosppy
    
def controllo_audio(file_name,op=''):
    try:
        file = np.load('../../Analisi audio/Work/'+file_name+'/'+file_name+op+'.npz')
        audio = file['amp']
        fs = file['fs']
    except FileNotFoundError:
        print('\nIl file non esiste!\n')
    return audio,fs

# --------------- LOAD ---------------- #
""" Funzione iniziale da eseguire sempre, esegue ogni check sulla validità dei dati inseriti
    a monte, così da avere un procedura più snella per le funzioni successive
"""
def audio_load(fin,N):
    Nmax = 20000
    while N>Nmax or N<0: # controllo di avere un numero corretto di campioni
        if N>50000:
            N = int(input('Inserire numero di campioni minore di {}: '.format(Nmax)))
        elif N<=0:
            N = int(input('Inserire numero positivo di campioni: '))
    fini = '../../Analisi audio/Dati/'+fin+'.wav' 
    try:
        file = open(fini,'r')
    except FileNotFoundError:
        print('\nIl file non esiste!\n')
            
    file.close()    
    (fs,amp) = wv.read(fini,True) # tupla di 2 elementi
    #print(fs)
    #print(amp_audio)
    #print(len(amp_audio))
    
    rr = np.size(amp) # Campioni per file a un canale

    #print(rr)
    if N>0 and N<rr:    # analisi degli ultimi N campioni
        amp = amp[:N]
    else:
        amp = amp[:rr]
        N = rr

    try:
        os.makedirs('../../Analisi audio/Work/'+fin)
    except FileExistsError:
        print('File già esistente ed ora eliminato, rilanciare il programma')

    np.savez('../../Analisi audio/Work/'+fin+'/'+fin+'.npz',amp=amp,fs=fs)
    print('Frequenza di campionamento: {} Hz'.format(fs))
    print(amp) 
    print(np.size(amp))

    #return fs,audio 


# --------------- PLOT ---------------- #
"""Funzione per stampare tutti gli elementi generati dal sistema"""
def audio_plot(file_name,op=''):

    audio,fs = controllo_audio(file_name,op)
    
    #t = (np.arange(np.size(audio)))/fs #vettore temporale    
    durata = len(audio)
    t = np.arange(0,durata)/fs
    plt.figure(figsize=(10,8)) # Dimensione della pagina che presenta il grafico
    plt.plot(t,audio)
    plt.grid() # Formazione della griglia
    plt.title('Segnale audio '+file_name) #imposto titolo
    plt.xlabel('t [s]') #imposto nome delle ascisse
    plt.ylabel('Ampiezza') #imposto nome delle ordinate
    plt.show()   

# --------------- PLAY ---------------- #
def audio_play(file_name,op=''):
    # eseguo il file generato
    audio,fs = controllo_audio(file_name,op)
    
    wv.write(file_name+'.wav',fs,audio)
    wave_obj = sa.WaveObject.from_wave_file('../../Analisi audio/Dati/'+file_name+'/'+file_name+'.wav')
    play_obj = wave_obj.play()
    play_obj.wait_done()
    
    
# --------------- STOP ---------------- #
def audio_stop(file_name,op=''):
    wave_obj = sa.WaveObject.from_wave_file('../../Analisi audio/Dati/'+file_name+'/'+file_name+'.wav')
    stop_obj = wave_obj.stop()
    
    
# ------------ SPECTRE ---------------- #
def audio_spec(file_name,T,op=''):

    audio,fs = controllo_audio(file_name,op)
        
    freq,power=sp.signal.welch(audio,fs,T)

    plt.figure(figsize=(10,8)) 
    plt.plot(freq,power)
    plt.grid() 
    plt.title('Spettro di densità di potenza') # titolo
    plt.xlabel('Frequenza (Hz)') # nome delle ascisse
    plt.ylabel('Ampiezza (dB)') # nome delle ordinate
    plt.show()

# ------------- FILTRO ---------------- #
def audio_filtro(file_name,fL=0,fH=0,op=''):

    audio,fs = controllo_audio(file_name,op)
       
    durata = np.size(audio) # Campioni per file a un canale
    
    t = np.arange(0,durata,1/fs)
    freqs = fftfreq(durata, t[1]-t[0])
    segnale,k,l=biosppy.signals.tools.filter_signal(signal=audio, ftype='butter',order=4 ,band='bandpass',frequency=[fL,fH], sampling_rate=fs)

    plt.figure(figsize=(10,8))

    plt.subplot(311)
    plt.xlabel('Tempo [s]')
    plt.ylabel('Ampiezza')
    plt.plot(t[:durata],audio[:durata])

    plt.subplot(312)
    plt.plot(t[:durata], segnale[:durata])
    plt.xlabel('Tempo [s]')
    plt.ylabel('Ampiezza')

    plt.subplot(313)
    plt.plot(freqs,abs(sp.fft.fft(fft(segnale))))
    plt.title('TdF filtrata')
    plt.xlabel('Frequenza [Hz]')
    plt.ylabel('Ampiezza')

    plt.show()

    np.savez('../../Analisi audio/Work/'+file_name+'/'+file_name+'fil.npz',amp=segnale,fs=fs)

# ------------ ADD SIN --------------- #
def audio_addsin (file_name,A,f0,op=''):

    audio,fs = controllo_audio(file_name,op)
        
    t = np.arange(np.size(audio))/fs
    y = A * np.sin(2 * math.pi * f0 * t)
    audio_sin = audio + y

    np.savez('../../Analisi audio/Work/'+file_name+'/'+file_name+'sin.npz',amp=audio_sin,fs=fs)

    print('\nIl disturbo sinusoidale è stato aggiunto \n')
    print('Il file '+file_name+'sin.npz è stato salvato\n')

# -------------- NOISE --------------- #
def audio_addnoise(file_name,fL,fH,SNRdB,op=''):
    
    audio,fs = controllo_audio(file_name,op)
    
    SNR=10**(SNRdB/20) 
    rumore=np.random.standard_normal(np.size(audio)) #Definisco il rumore bianco
    rumf,k,l=biosppy.signals.tools.filter_signal(signal=rumore, ftype='butter',order=4 ,band='bandpass',frequency=[fL,fH], sampling_rate=fs)
    #Filtro il rumore bianco e lascio passare solo la banda compresa tra f0 e f1
    rmsx=math.sqrt(np.mean(audio**2)) #Calcolo il root mean square del segnale ECG
    rmsr=math.sqrt(np.mean(rumf**2)) #Calcolo il root mean square del processo bianco
    a=rmsx/(rmsr*SNR) #Definisco la costante a, che moltiplicata con il rumore filtrato, mi da luogo al SNR desiderato
    y = a*rumf
    noise = x+y
    np.savez('../../Analisi audio/Work/'+file_name+'/'+file_name+'noise.npz',amp=noise,fs=fs)
    print('Il file '+file_name+'noise.npz è stato salvato\n')

    #ecg più rumore dato dalla sinuoside col nome ecg_noise nella sottocartella Wrk
    

    
  
